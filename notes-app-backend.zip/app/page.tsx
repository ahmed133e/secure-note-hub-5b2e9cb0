'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import AuthPage from '@/components/auth-page';
import DashboardPage from '@/components/dashboard-page';

export default function Home() {
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    const storedToken = localStorage.getItem('token');
    const storedUsername = localStorage.getItem('username');
    
    if (storedToken && storedUsername) {
      setToken(storedToken);
    }
    setLoading(false);
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-8 h-8 border-3 border-primary border-t-transparent rounded-full animate-spin"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!token) {
    return <AuthPage onAuthSuccess={(token, username) => {
      setToken(token);
      localStorage.setItem('token', token);
      localStorage.setItem('username', username);
    }} />;
  }

  return <DashboardPage token={token} onLogout={() => {
    setToken(null);
    localStorage.removeItem('token');
    localStorage.removeItem('username');
  }} />;
}
