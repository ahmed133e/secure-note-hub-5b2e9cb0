'use client';

import { formatDistanceToNow } from 'date-fns';

interface Note {
  id: number;
  title: string;
  content: string;
  created_at: string;
  updated_at: string;
}

interface NotesListProps {
  notes: Note[];
  selectedNote: Note | null;
  onSelectNote: (note: Note) => void;
}

export default function NotesList({
  notes,
  selectedNote,
  onSelectNote,
}: NotesListProps) {
  return (
    <div className="space-y-2 p-4">
      {notes.length === 0 ? (
        <p className="text-sm text-muted-foreground text-center py-8">No notes yet</p>
      ) : (
        notes.map((note) => (
          <button
            key={note.id}
            onClick={() => onSelectNote(note)}
            className={`w-full text-left p-3 rounded-lg transition-colors border ${
              selectedNote?.id === note.id
                ? 'bg-primary/10 border-primary text-foreground'
                : 'bg-secondary hover:bg-secondary/80 border-border text-foreground'
            }`}
          >
            <p className="font-medium text-sm truncate">{note.title}</p>
            <p className="text-xs text-muted-foreground mt-1">
              {formatDistanceToNow(new Date(note.updated_at), { addSuffix: true })}
            </p>
          </button>
        ))
      )}
    </div>
  );
}
