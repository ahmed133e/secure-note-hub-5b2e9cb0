'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Trash2 } from 'lucide-react';

interface Note {
  id: number;
  title: string;
  content: string;
  created_at: string;
  updated_at: string;
}

interface NoteEditorProps {
  note: Note;
  onUpdate: (note: Note) => void;
  onDelete: (id: number) => void;
}

export default function NoteEditor({ note, onUpdate, onDelete }: NoteEditorProps) {
  const [title, setTitle] = useState(note.title);
  const [content, setContent] = useState(note.content);
  const [hasChanges, setHasChanges] = useState(false);

  useEffect(() => {
    setTitle(note.title);
    setContent(note.content);
    setHasChanges(false);
  }, [note]);

  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTitle(e.target.value);
    setHasChanges(true);
  };

  const handleContentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setContent(e.target.value);
    setHasChanges(true);
  };

  const handleSave = () => {
    onUpdate({
      ...note,
      title: title || 'Untitled Note',
      content,
    });
    setHasChanges(false);
  };

  const handleDelete = () => {
    if (confirm('Are you sure you want to delete this note?')) {
      onDelete(note.id);
    }
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="border-b border-border p-6 flex items-center justify-between">
        <div className="flex-1">
          <Input
            value={title}
            onChange={handleTitleChange}
            className="text-3xl font-bold bg-transparent border-none p-0 placeholder:text-muted-foreground text-foreground h-auto"
            placeholder="Note title"
          />
        </div>
        <div className="flex gap-2 ml-4">
          {hasChanges && (
            <Button
              onClick={handleSave}
              className="bg-primary hover:bg-primary/90 text-primary-foreground"
            >
              Save
            </Button>
          )}
          <Button
            onClick={handleDelete}
            variant="ghost"
            className="text-destructive hover:bg-destructive/10"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Editor */}
      <div className="flex-1 p-6 overflow-auto">
        <textarea
          value={content}
          onChange={handleContentChange}
          className="w-full h-full bg-transparent text-foreground placeholder:text-muted-foreground resize-none focus:outline-none"
          placeholder="Start typing your note..."
        />
      </div>
    </div>
  );
}
