# Notes Application - Deployment Guide

## Architecture Overview

```
[Internet] 
    ↓
[Front Firewall (DMZ)]
    ↓
[Frontend Server] ← (React App)
    ↓
[Dorsal Firewall (LAN)]
    ↓
[Backend Server] ← (Node.js API + SQLite Database)
```

## Database Schema

### Users Table
```sql
CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### Notes Table
```sql
CREATE TABLE notes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  content TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX idx_notes_user_id ON notes(user_id);
```

---

## Backend Deployment (LAN - Behind Dorsal Firewall)

### 1. Prerequisites
```bash
# Install Node.js (v14 or higher)
# Install npm packages
```

### 2. Setup Backend

Create `package.json`:
```json
{
  "name": "notes-backend",
  "version": "1.0.0",
  "main": "server.js",
  "scripts": {
    "start": "node server.js",
    "dev": "nodemon server.js"
  },
  "dependencies": {
    "express": "^4.18.2",
    "sqlite3": "^5.1.6",
    "bcrypt": "^5.1.1",
    "jsonwebtoken": "^9.0.2",
    "cors": "^2.8.5"
  },
  "devDependencies": {
    "nodemon": "^3.0.1"
  }
}
```

### 3. Install Dependencies
```bash
npm install
```

### 4. Configure Environment Variables

Create `.env` file:
```env
PORT=3000
JWT_SECRET=change-this-to-a-secure-random-string-in-production
FRONTEND_URL=http://your-dmz-frontend-ip
NODE_ENV=production
```

### 5. Start Backend Server
```bash
# Development
npm run dev

# Production
npm start
```

### 6. Firewall Rules (Dorsal Firewall)
Allow inbound traffic from DMZ frontend server:
```
Source: DMZ_Frontend_IP
Destination: LAN_Backend_IP
Port: 3000
Protocol: TCP
Action: ALLOW
```

---

## Frontend Deployment (DMZ - Behind Front Firewall)

### 1. Build Frontend

Create `package.json`:
```json
{
  "name": "notes-frontend",
  "version": "1.0.0",
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "lucide-react": "^0.263.1"
  },
  "scripts": {
    "build": "react-scripts build",
    "start": "react-scripts start"
  }
}
```

### 2. Update API Configuration

In the frontend React component, update the `API_URL`:
```javascript
const API_URL = 'http://YOUR_BACKEND_LAN_IP:3000/api';
```

### 3. Build and Deploy
```bash
npm install
npm run build

# Deploy the build folder to your web server
# Example for nginx:
sudo cp -r build/* /var/www/html/
```

### 4. Nginx Configuration (DMZ)
```nginx
server {
    listen 80;
    server_name your-domain.com;

    root /var/www/html;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    # CORS headers if needed
    add_header Access-Control-Allow-Origin *;
}
```

### 5. Firewall Rules (Front Firewall)
```
# Allow HTTP/HTTPS from Internet
Source: ANY
Destination: DMZ_Frontend_IP
Ports: 80, 443
Action: ALLOW

# Allow outbound to backend
Source: DMZ_Frontend_IP
Destination: LAN_Backend_IP
Port: 3000
Action: ALLOW
```

---

## Security Recommendations

### 1. JWT Secret
Generate a strong secret:
```bash
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
```

### 2. HTTPS Configuration
Use SSL/TLS certificates (Let's Encrypt):
```bash
sudo certbot --nginx -d your-domain.com
```

### 3. Rate Limiting
Add to backend:
```javascript
const rateLimit = require('express-rate-limit');

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100 // limit each IP to 100 requests per windowMs
});

app.use('/api/', limiter);
```

### 4. Password Requirements
- Minimum 6 characters (configurable)
- Consider adding: uppercase, lowercase, numbers, special chars

### 5. Database Backup
```bash
# Backup SQLite database
sqlite3 notes.db ".backup 'notes_backup.db'"

# Automate with cron
0 2 * * * sqlite3 /path/to/notes.db ".backup '/path/to/backup/notes_$(date +\%Y\%m\%d).db'"
```

---

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login and get JWT token

### Notes (Requires Authentication)
- `GET /api/notes` - Get all user notes
- `GET /api/notes/:id` - Get specific note
- `POST /api/notes` - Create new note
- `PUT /api/notes/:id` - Update note
- `DELETE /api/notes/:id` - Delete note

### Health Check
- `GET /api/health` - Server health status

---

## Testing

### Test Backend API
```bash
# Register user
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"testuser","password":"password123"}'

# Login
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"testuser","password":"password123"}'

# Create note (replace YOUR_TOKEN)
curl -X POST http://localhost:3000/api/notes \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{"title":"My Note","content":"Note content"}'

# Get notes
curl http://localhost:3000/api/notes \
  -H "Authorization: Bearer YOUR_TOKEN"
```

---

## Monitoring

### Backend Logs
```bash
# View logs
tail -f server.log

# Or use PM2 for process management
npm install -g pm2
pm2 start server.js --name notes-api
pm2 logs notes-api
```

### Database Monitoring
```bash
# Check database size
ls -lh notes.db

# Query user count
sqlite3 notes.db "SELECT COUNT(*) FROM users;"

# Query notes count
sqlite3 notes.db "SELECT COUNT(*) FROM notes;"
```

---

## Troubleshooting

### CORS Issues
If frontend can't connect to backend:
1. Check CORS configuration in `server.js`
2. Verify `FRONTEND_URL` in `.env`
3. Check browser console for CORS errors

### Authentication Errors
1. Verify JWT_SECRET is same across restarts
2. Check token expiration (24h default)
3. Verify Authorization header format: `Bearer <token>`

### Database Errors
1. Check file permissions: `chmod 644 notes.db`
2. Verify SQLite is installed: `sqlite3 --version`
3. Check disk space: `df -h`

---

## Production Checklist

- [ ] Change JWT_SECRET to secure random string
- [ ] Enable HTTPS with SSL certificates
- [ ] Configure firewall rules correctly
- [ ] Set up database backups (daily/weekly)
- [ ] Implement rate limiting
- [ ] Set up monitoring and logging
- [ ] Test all API endpoints
- [ ] Verify CORS configuration
- [ ] Document admin procedures
- [ ] Plan disaster recovery